import { Button } from "../components/ui/button"
import { ArrowRight } from "lucide-react"
import "../styles/hero.css"

export default function Hero() {
  const scrollToSection = (id) => {
    const element = document.getElementById(id)
    element?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section className="hero-section">
      <div className="hero-content-wrapper">
        <div className="hero-content">
          <div className="hero-text-content animate-fade-in-up">
            <h1 className="hero-main-title">
              Build & Improve Solution to <span className="hero-accent-text">The Better Future</span>
            </h1>
            <p className="hero-tagline">
              We are holding company focus on finance, property, technology, also renewable energy
            </p>
            <Button size="lg" className="hero-cta-button" onClick={() => scrollToSection('portfolio-preview')}>
              See Our Work
              <ArrowRight className="hero-button-icon" size={16} />
            </Button>
          </div>
        </div>

        <div className="hero-image-section animate-fade-in-up delay-200">
          <div className="hero-image-wrapper">
            <img 
              src="/modern-office-building.png" 
              alt="Modern Office Building" 
              className="hero-building-image"
            />
            <div className="hero-image-overlay"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
