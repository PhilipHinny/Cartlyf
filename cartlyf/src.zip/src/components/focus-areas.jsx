"use client"

import { useState, useEffect, useRef } from "react"
import { ChevronDown, Home, DollarSign, Zap, TrendingUp } from "lucide-react"
import "../styles/focus-areas.css"

export default function FocusAreas() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeIndex, setActiveIndex] = useState(0)
  const sectionRef = useRef(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  const focusAreas = [
    {
      icon: Home,
      title: "Ensure Great Property",
      description: "Thousands of homes increased every year. That also offers the property needs. Our goals are to promote great property to people around the world.",
      color: "#f59e0b"
    },
    {
      icon: DollarSign,
      title: "Stabilize Finance Condition",
      description: "We provide comprehensive financial solutions to ensure stable economic growth. Our expertise helps secure sustainable funding for long-term success.",
      color: "#3b82f6"
    },
    {
      icon: Zap,
      title: "Advance Technology Class",
      description: "Leveraging cutting-edge technology to build innovative solutions. We stay ahead of the curve with modern tech stacks and development practices.",
      color: "#a855f7"
    },
    {
      icon: TrendingUp,
      title: "Support Battery Production",
      description: "Contributing to sustainable energy solutions through battery technology support. We're part of Africa's green energy transformation.",
      color: "#10b981"
    }
  ]

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? -1 : index)
  }

  return (
    <section id="focus-areas" className="focus-areas-section" ref={sectionRef}>
      <div className="focus-areas-container">
        <div className={`focus-areas-header ${isVisible ? 'fade-in-up' : ''}`}>
          <div className="section-badge">
            <span className="badge-dot" />
            What We Do
          </div>
          <h2 className="focus-areas-title">Our Focused Area</h2>
          <p className="focus-areas-description">
            We are holding company focus on finance, property, technology, also renewable energy. 
            Our diverse portfolio ensures sustainable growth and innovation across multiple sectors.
          </p>
        </div>

        <div className="focus-areas-content">
          <div className={`focus-areas-accordion ${isVisible ? 'fade-in-up delay-200' : ''}`}>
            {focusAreas.map((area, index) => {
              const Icon = area.icon
              const isActive = activeIndex === index

              return (
                <div key={index} className={`accordion-item ${isActive ? 'active' : ''}`}>
                  <button
                    className="accordion-trigger"
                    onClick={() => toggleAccordion(index)}
                    style={{ borderLeftColor: isActive ? area.color : 'transparent' }}
                  >
                    <div className="accordion-trigger-content">
                      <div 
                        className="accordion-icon-wrapper"
                        style={{ backgroundColor: isActive ? `${area.color}15` : 'transparent' }}
                      >
                        <Icon 
                          className="accordion-icon" 
                          style={{ color: isActive ? area.color : '#64748b' }}
                        />
                      </div>
                      <span className="accordion-title">{area.title}</span>
                    </div>
                    <ChevronDown 
                      className={`accordion-chevron ${isActive ? 'rotate' : ''}`}
                      style={{ color: area.color }}
                    />
                  </button>
                  
                  <div className={`accordion-content ${isActive ? 'open' : ''}`}>
                    <p className="accordion-description">{area.description}</p>
                  </div>
                </div>
              )
            })}
          </div>

          <div className={`focus-areas-stats ${isVisible ? 'fade-in-up delay-400' : ''}`}>
            <div className="stat-item">
              <div className="stat-number">1134</div>
              <div className="stat-label">Total Employee</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">32</div>
              <div className="stat-label">Our Brand in world</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">2145</div>
              <div className="stat-label">Profit Millions IDR 2020</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">28%</div>
              <div className="stat-label">Company Growth</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

