"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "../components/ui/button"
import { Input } from "../components/ui/input"
import { Textarea } from "../components/ui/textarea"
import { Card } from "../components/ui/card"
import { Mail, Phone, MapPin, Send, Linkedin, Twitter, Github, MessageCircle } from "lucide-react"
import "../styles/contact.css"

export default function Contact() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    subject: "",
    message: "",
  })

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    // Add your form submission logic here
    alert("Thank you for reaching out! We'll get back to you soon.")
    setFormData({ name: "", email: "", company: "", subject: "", message: "" })
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const contactInfo = [
    {
      icon: Mail,
      title: "Email Us",
      details: ["hello@cartlyf.tech", "investors@cartlyf.tech"],
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Phone,
      title: "Call Us",
      details: ["+254 (0) 700 000 000", "Mon-Fri, 9am-6pm EAT"],
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: MapPin,
      title: "Visit Us",
      details: ["Nairobi, Kenya", "East Africa Hub"],
      color: "from-orange-500 to-red-500"
    }
  ]

  return (
    <section id="contact" className="contact-section" ref={sectionRef}>
      <div className="contact-container">
        <div className={`contact-header ${isVisible ? 'fade-in-up' : ''}`}>
          <div className="section-badge">
            <span className="badge-dot" />
            Let's Connect
          </div>
          <h2 className="contact-title">Ready to Build the Future Together?</h2>
          <p className="contact-description">
            Whether you're an investor, potential partner, talented developer, or just curious about what we're building - 
            we'd love to hear from you. Let's create something amazing for Africa.
          </p>
        </div>

        <div className="contact-grid">
          <div className={`contact-form-section ${isVisible ? 'fade-in-up delay-200' : ''}`}>
            <Card className="contact-form-card">
              <div className="form-header">
                <MessageCircle className="form-header-icon" />
                <div>
                  <h3 className="form-title">Send us a message</h3>
                  <p className="form-subtitle">We typically respond within 24 hours</p>
                </div>
              </div>
              <form onSubmit={handleSubmit} className="contact-form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="name">Full Name *</label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="email">Email Address *</label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="john@example.com"
                      required
                    />
                  </div>
                </div>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="company">Company / Organization</label>
                    <Input
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      placeholder="Your Company (Optional)"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="subject">Subject *</label>
                    <Input
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      placeholder="What's this about?"
                      required
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label htmlFor="message">Your Message *</label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us about your inquiry, partnership opportunity, or investment interest..."
                    rows={6}
                    required
                  />
                </div>
                <Button type="submit" className="submit-button" size="lg">
                  <Send size={18} />
                  Send Message
                </Button>
              </form>
            </Card>
          </div>

          <div className="contact-info-section">
            <div className={`contact-info-cards ${isVisible ? 'fade-in-up delay-400' : ''}`}>
              {contactInfo.map((info, index) => {
                const Icon = info.icon
                return (
                  <Card key={index} className="contact-info-card">
                    <div className={`contact-icon-wrapper ${info.color}`}>
                      <Icon className="contact-icon" />
                    </div>
                    <h3 className="contact-info-title">{info.title}</h3>
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="contact-info-text">{detail}</p>
                    ))}
                  </Card>
                )
              })}
            </div>

            <Card className={`contact-social-card ${isVisible ? 'fade-in-up delay-600' : ''}`}>
              <h3 className="social-title">Follow Our Journey</h3>
              <p className="social-description">
                Stay updated on our latest products, achievements, and insights into building tech for Africa.
              </p>
              <div className="social-links">
                <a href="#" className="social-link linkedin">
                  <Linkedin size={20} />
                </a>
                <a href="#" className="social-link twitter">
                  <Twitter size={20} />
                </a>
                <a href="#" className="social-link github">
                  <Github size={20} />
                </a>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
