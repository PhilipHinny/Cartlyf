"use client"

import { Card } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { Linkedin, Twitter, Mail, ArrowRight } from "lucide-react"
import { useEffect, useRef, useState } from "react"
import "../styles/team.css"

export default function Team() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  const teamMembers = [
    {
      name: "Robert Kinyua",
      role: "Founder & CEO",
      image: "/placeholder-user.jpg",
      bio: "Visionary leader with 10+ years in tech innovation",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "robert@cartlyf.tech"
      }
    },
    {
      name: "Sarah Mwangi",
      role: "Chief Technology Officer",
      image: "/placeholder-user.jpg",
      bio: "Full-stack engineer passionate about scalable solutions",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "sarah@cartlyf.tech"
      }
    },
    {
      name: "James Omondi",
      role: "Head of Product",
      image: "/placeholder-user.jpg",
      bio: "Product strategist focused on user-centric design",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "james@cartlyf.tech"
      }
    },
    {
      name: "Grace Kamau",
      role: "Chief Marketing Officer",
      image: "/placeholder-user.jpg",
      bio: "Growth expert with expertise in African markets",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "grace@cartlyf.tech"
      }
    },
    {
      name: "David Njoroge",
      role: "Lead Developer",
      image: "/placeholder-user.jpg",
      bio: "Software architect building robust systems",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "david@cartlyf.tech"
      }
    },
    {
      name: "Mary Achieng",
      role: "UX/UI Designer",
      image: "/placeholder-user.jpg",
      bio: "Creative designer crafting beautiful experiences",
      social: {
        linkedin: "#",
        twitter: "#",
        email: "mary@cartlyf.tech"
      }
    }
  ]

  return (
    <section id="team" className="team-section" ref={sectionRef}>
      <div className="team-container">
        <div className={`team-header ${isVisible ? 'fade-in-up' : ''}`}>
          <div className="section-badge">
            <span className="badge-dot" />
            Our Team
          </div>
          <h2 className="team-title">Meet Our Team</h2>
          <p className="team-description">
            The talented individuals behind CartLyf Technologies. Our diverse team brings together 
            expertise in technology, business, and African market insights to build world-class products.
          </p>
        </div>

        <div className="team-grid">
          {teamMembers.map((member, index) => (
            <Card 
              key={index} 
              className={`team-card ${isVisible ? 'fade-in-up' : ''}`}
              style={{ transitionDelay: `${index * 0.1}s` }}
            >
              <div className="team-image-wrapper">
                <img 
                  src={member.image || "/placeholder-user.jpg"} 
                  alt={member.name} 
                  className="team-image" 
                />
                <div className="team-overlay">
                  <div className="team-social">
                    <a href={member.social.linkedin} className="team-social-link">
                      <Linkedin size={18} />
                    </a>
                    <a href={member.social.twitter} className="team-social-link">
                      <Twitter size={18} />
                    </a>
                    <a href={`mailto:${member.social.email}`} className="team-social-link">
                      <Mail size={18} />
                    </a>
                  </div>
                </div>
              </div>
              <div className="team-content">
                <h3 className="team-member-name">{member.name}</h3>
                <p className="team-member-role">{member.role}</p>
                <p className="team-member-bio">{member.bio}</p>
              </div>
            </Card>
          ))}
        </div>

        <div className={`team-cta ${isVisible ? 'fade-in-up delay-600' : ''}`}>
          <div className="team-cta-content">
            <h3 className="team-cta-title">Want to Join Our Team?</h3>
            <p className="team-cta-description">
              We're always looking for talented, passionate individuals who want to make a difference in Africa's tech ecosystem.
            </p>
            <Button size="lg" className="team-cta-button">
              View Open Positions
              <ArrowRight className="ml-2" size={18} />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

